Training
a2c_mod.py is the script used to train the model for the first round of training.
a2c_mod_cont.py is the script used to train the model for subsequent rounds of training.
test.py is the script used to generate the evalutation metrics.

Intermediate results
The .pkl files and graphs from each training round are stored here.

Leaderboard Submission
The .zip file submitted to the leaderboard is stored here.