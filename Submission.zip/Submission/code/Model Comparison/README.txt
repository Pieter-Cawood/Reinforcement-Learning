Each folder contains a test.py script that will run the trained agents on a 100 runs
and produce the performance metrics summarised in "Comparison Results.xlsx".